
public class Main {

	public static void main(String[] args) {
		Node[] nodes = new Node[6];
		nodes[0] = new Node(0.1638, 'c');
		nodes[1] = new Node(0.0454, 'v');
		nodes[2] = new Node(0.0871, 'w');
		nodes[3] = new Node(0.1957, 'u');
		nodes[4] = new Node(0.4209, 'r');
		nodes[5] = new Node(0.0871, 'z');
		
		Tree huffman = new Tree(nodes);
		
		System.out.println(huffman.toString());
		System.out.println(String.valueOf(huffman.sumOfFrequencies()));
		huffman.print();
	}
}
